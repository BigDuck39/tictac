﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SimpleTCP;

namespace sTcpServer
{
    public partial class Form1 : Form
    {
        SimpleTcpServer server = new SimpleTcpServer();
        public Form1()
        {
            InitializeComponent();
        }
        private void gas()
        {
            server.Broadcast(Encoding.UTF8.GetBytes("gas gas gas"));
        }
        private void button1_Click(object sender, EventArgs e)
        {
            

            server.ClientConnected += (sender, e) => listBox1.Items.Add($"Cleint ({e.Client.RemoteEndPoint}) connecte!");
            server.ClientDisconnected += (sender, e) => listBox1.Items.Add($"Cleint ({e.Client.RemoteEndPoint}) disconeted!");
            
            server.DataReceived += (server, e) =>
            {
                var ep = e.TcpClient.Client.RemoteEndPoint;
                var msg = Encoding.UTF8.GetString(e.Data);
                listBox1.Items.Add($"Recived message from {ep}: \"{msg}\".");

                e.Reply(Encoding.UTF8.GetBytes("Hello BAck!"));
                gas();
                

            };

            server.Start(50000);

            server.Broadcast(Encoding.UTF8.GetBytes("gas gas gas"));

        }

        private void button2_Click(object sender, EventArgs e)
        {
            server.Broadcast(Encoding.UTF8.GetBytes("gas gas gas"));
        }
    }
}
