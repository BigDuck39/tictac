﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SimpleTCP;

namespace sTcpClient
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        bool gas = true;
        private void button1_Click(object sender, EventArgs e)
        {
            var client = new SimpleTcpClient();

            client.DataReceived += (sender, e) =>
            {
                var msg = Encoding.UTF8.GetString(e.Data);
                listBox1.Items.Add($"Recived : \"{msg}\".");
            };
            if (gas)
            {

                client.Connect("127.0.0.1", 50000);
                gas = !gas;
            }

            client.Write(Encoding.UTF8.GetBytes(textBox1.Text.ToString()));
            
        }
    }
}
