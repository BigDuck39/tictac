﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SimpleTCP;

namespace WinFormsApp5 {
    public partial class Form1 : Form {
        SimpleTcpServer server = new SimpleTcpServer();
        int id = 0;
        public Form1() {
            InitializeComponent();
        }
        private void gas() {
            server.Broadcast(Encoding.UTF8.GetBytes("gas gas gas"));
        }

        private void textBox1_TextChanged(object sender, EventArgs e) {

        }

        private void button3_Click(object sender, EventArgs e) {
            server.ClientConnected += (sender, e) => {
                listBox1.Items.Add($"Cleint ({e.Client.RemoteEndPoint}) connecte!");

            };

            server.ClientDisconnected += (sender, e) => listBox1.Items.Add($"Cleint ({e.Client.RemoteEndPoint}) disconeted!");
            server.DataReceived += (server2, e) => {
                var ep = e.TcpClient.Client.RemoteEndPoint;
                var msg = Encoding.UTF8.GetString(e.Data);
                listBox1.Items.Add($"Recived message from {ep}: \"{msg}\".");

                string[] ok = msg.ToString().Split(" ");

                if (msg.Contains("#.#")) {

                    e.Reply("#.# " + id.ToString() + " " + ok[1]);
                    id++;
                }
                if (msg.Contains(":")) {
                    server.Broadcast(Encoding.UTF8.GetBytes(msg.ToString()));
                }



                //e.Reply(Encoding.UTF8.GetBytes("Hello BAck!"));





            };
            try {
                server.Start(int.Parse(textBox2.Text.ToString()));
            } catch {

            }
            }


    }
}
