﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SimpleTCP;

namespace WinFormsApp6 {
    public partial class Form1 : Form {
        string username = "";
        SimpleTcpClient client = new SimpleTcpClient();
        public Form1() {
            InitializeComponent();
            client.DataReceived += (sender, e) => {
                var msg = Encoding.UTF8.GetString(e.Data);
                char[] charArr = msg.ToString().ToCharArray();
                //listBox1.Items.Add($"Recived : \"{msg}\".");

                string[] ok = msg.ToString().Split(" ");

                if(ok[0] == "#.#") {
                    username += ok[1] + " "+  ok[2]+": ";
                    listBox1.Items.Add(username);
                }

                if (msg.Contains(":")) {
                    listBox1.Items.Add(msg);
                }


            };
        }

        private void button1_Click(object sender, EventArgs e) {



            if (textBox3.Text.ToString() == "") {
                label3.Text = "niste unijeli username";
            } else {
                try {
                    client.Connect(textBox4.Text.ToString(), int.Parse(textBox2.Text.ToString())); ;
                    client.Write("#.# " + textBox3.Text.ToString());

                    button1.Enabled = false;
                    textBox2.Enabled = false;
                    textBox3.Enabled = false;
                    textBox4.Enabled = false;

                } catch {
                    label3.Text = "niste unijeli dobar port ili ip adresu";
                }
                
            }
        }

        private void button2_Click(object sender, EventArgs e) {
            if(textBox1.Text.ToString() == "") {
                label4.Text = "nemožete poslati praznu poruku";
            } else {
                label4.Text = "";
                client.Write(Encoding.UTF8.GetBytes(username + textBox1.Text.ToString()));
            }
            
        }

        private void label1_Click(object sender, EventArgs e) {

        }

        private void spremiToolStripMenuItem_Click(object sender, EventArgs e) {
            StreamWriter sw = new StreamWriter(@"D:\ip.txt");

            sw.WriteLine(textBox2.Text.ToString());
            sw.WriteLine(textBox4.Text.ToString());

            sw.Close();



        }

        private void učitajToolStripMenuItem_Click(object sender, EventArgs e) {
            StreamReader sr = new StreamReader(@"D:\ip.txt");

            textBox2.Text = sr.ReadLine();
            textBox4.Text = sr.ReadLine();


            sr.Close();
        }

        private void Form1_Load(object sender, EventArgs e) {

        }
    }
}











       