﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SimpleTCP;

namespace sTcpServer
{
    public partial class Form1 : Form
    {
        SimpleTcpServer server = new SimpleTcpServer();
        string turn = "1";
        int p = 1;
        string polje = "";
        char[] polje2 = new char[9];
        public Form1()
        {
            InitializeComponent();
        }
        private void gas()
        {
            server.Broadcast(Encoding.UTF8.GetBytes("gas gas gas"));
        }
        private void button1_Click(object sender, EventArgs e)
        {


            server.ClientConnected += (sender, e) => {
                listBox1.Items.Add($"Cleint ({e.Client.RemoteEndPoint}) connecte!");

            };
            server.ClientDisconnected += (sender, e) => listBox1.Items.Add($"Cleint ({e.Client.RemoteEndPoint}) disconeted!");
            
            server.DataReceived += (server2, e) =>
            {
                var ep = e.TcpClient.Client.RemoteEndPoint;
                var msg = Encoding.UTF8.GetString(e.Data);
                listBox1.Items.Add($"Recived message from {ep}: \"{msg}\".");

                //e.Reply(Encoding.UTF8.GetBytes("Hello BAck!"));

                if (p % 2 == 0 && msg.ToString() == "p") {
                    e.Reply(Encoding.UTF8.GetBytes("2"));
                    p++;
                } else if(p % 2 != 0 && msg.ToString() == "p") {
                    e.Reply(Encoding.UTF8.GetBytes("1"));
                    p++;
                }

                if(msg.ToString().Contains("x") || msg.ToString().Contains("o")) {
                    polje = msg.ToString();
             
                }
                char[] charArr = polje.ToCharArray();
                for(int i = 0; i < 9; i++) {
                    polje2[i] = charArr[i];
                }
                string charsStr = new string(polje2);
       
                server.Broadcast(Encoding.UTF8.GetBytes(charsStr));

                if (charsStr[0] == 'x' && charsStr[1] == 'x' && charsStr[2] == 'x') {
                    server.Broadcast(Encoding.UTF8.GetBytes("x je pobjednik"));
                }
                if (charsStr[3] == 'x' && charsStr[4] == 'x' && charsStr[5] == 'x') {
                    server.Broadcast(Encoding.UTF8.GetBytes("x je pobjednik"));
                }
                if (charsStr[6] == 'x' && charsStr[7] == 'x' && charsStr[8] == 'x') {
                    server.Broadcast(Encoding.UTF8.GetBytes("x je pobjednik"));
                }


                if (charsStr[0] == 'x' && charsStr[3] == 'x' && charsStr[6] == 'x') {
                    server.Broadcast(Encoding.UTF8.GetBytes("x je pobjednik"));
                }

                if (charsStr[1] == 'x' && charsStr[4] == 'x' && charsStr[7] == 'x') {
                    server.Broadcast(Encoding.UTF8.GetBytes("x je pobjednik"));
                }

                if (charsStr[2] == 'x' && charsStr[5] == 'x' && charsStr[8] == 'x') {
                    server.Broadcast(Encoding.UTF8.GetBytes("x je pobjednik"));
                }

                if (charsStr[0] == 'x' && charsStr[4] == 'x' && charsStr[8] == 'x') {
                    server.Broadcast(Encoding.UTF8.GetBytes("x je pobjednik"));
                }
                if (charsStr[2] == 'x' && charsStr[4] == 'x' && charsStr[6] == 'x') {
                    server.Broadcast(Encoding.UTF8.GetBytes("x je pobjednik"));
                }




                if (charsStr[0] == 'o' && charsStr[1] == 'o' && charsStr[2] == 'o') {
                    server.Broadcast(Encoding.UTF8.GetBytes("o je pobjednik"));
                }
                if (charsStr[3] == 'o' && charsStr[4] == 'o' && charsStr[5] == 'o') {
                    server.Broadcast(Encoding.UTF8.GetBytes("o je pobjednik"));
                }
                if (charsStr[6] == 'o' && charsStr[7] == 'o' && charsStr[8] == 'o') {
                    server.Broadcast(Encoding.UTF8.GetBytes("o je pobjednik"));
                }


                if (charsStr[0] == 'o' && charsStr[3] == 'o' && charsStr[6] == 'o') {
                    server.Broadcast(Encoding.UTF8.GetBytes("o je pobjednik"));
                }

                if (charsStr[1] == 'o' && charsStr[4] == 'o' && charsStr[7] == 'o') {
                    server.Broadcast(Encoding.UTF8.GetBytes("o je pobjednik"));
                }

                if (charsStr[2] == 'o' && charsStr[5] == 'o' && charsStr[8] == 'o') {
                    server.Broadcast(Encoding.UTF8.GetBytes("o je pobjednik"));
                }

                if (charsStr[0] == 'o' && charsStr[4] == 'o' && charsStr[8] == 'o') {
                    server.Broadcast(Encoding.UTF8.GetBytes("o je pobjednik"));
                }
                if (charsStr[2] == 'o' && charsStr[4] == 'o' && charsStr[6] == 'o') {
                    server.Broadcast(Encoding.UTF8.GetBytes("o je pobjednik"));
                }




            };

            server.Start(50000);

           // server.Broadcast(Encoding.UTF8.GetBytes("gas gas gas"));

        }

        private void button2_Click(object sender, EventArgs e)
        {
            server.Broadcast(Encoding.UTF8.GetBytes("gas gas gas"));
        }
    }
}
