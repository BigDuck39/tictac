﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SimpleTCP;

namespace sTcpClient
{
    public partial class Form1 : Form
    {

        bool gas = true;
        SimpleTcpClient client = new SimpleTcpClient();
        char[] polje = new char[9];
        string turn = "x";
        public Form1()
        {
            InitializeComponent();
            for (int i = 0; i < 9; i++) {
                polje[i] = '*';
            }
            client.DataReceived += (sender, e) => {
                var msg = Encoding.UTF8.GetString(e.Data);
                char[] charArr = msg.ToString().ToCharArray();
                listBox1.Items.Add($"Recived : \"{msg}\".");
                if (msg.ToString().Contains("1")) {
                    turn = "x";
                } else if(msg.ToString().Contains("2"))  {
                    turn = "o";
                    freeze();
                }

                if (msg.ToString().Contains("x") && turn == "o") {
                    unFreeze();
                }
                if (msg.ToString().Contains("o") && turn == "x") {
                    unFreeze();
                }

                if (msg.ToString().Contains("x je")) {
                    label1.Text = "x je pobjednik";
                    freeze();
                }
                else if(msg.ToString().Contains("o je")) {
                    label1.Text = "o je pobjednik";
                    freeze();

                }
                

                if (charArr[0] == 'x') {
                    button3.Text = "x";
                    button3.Enabled = false;
                }
                else if(charArr[0] == 'o'){
                    button3.Text = "o";
                    button3.Enabled = false;
                }

                if (charArr[1] == 'x') {
                    button4.Text = "x";
                    button4.Enabled = false;
                } else if (charArr[1] == 'o') {
                    button4.Text = "o";
                    button4.Enabled = false;
                }

                if (charArr[2] == 'x') {
                    button5.Text = "x";
                    button5.Enabled = false;
                } else if (charArr[2] == 'o') {
                    button5.Text = "o";
                    button5.Enabled = false;
                }

                if (charArr[3] == 'x') {
                    button6.Text = "x";
                    button6.Enabled = false;
                } else if (charArr[3] == 'o') {
                    button6.Text = "o";
                    button6.Enabled = false;
                }

                if (charArr[4] == 'x') {
                    button7.Text = "x";
                    button7.Enabled = false;
                } else if (charArr[4] == 'o') {
                    button7.Text = "o";
                    button7.Enabled = false;
                }

                if (charArr[5] == 'x') {
                    button8.Text = "x";
                    button8.Enabled = false;
                } else if (charArr[5] == 'o') {
                    button8.Text = "o";
                    button8.Enabled = false;
                }

                if (charArr[6] == 'x') {
                    button9.Text = "x";
                    button9.Enabled = false;
                } else if (charArr[6] == 'o') {
                    button9.Text = "o";
                    button9.Enabled = false;
                }

                if (charArr[7] == 'x') {
                    button10.Text = "x";
                    button10.Enabled = false;
                } else if (charArr[7] == 'o') {
                    button10.Text = "o";
                    button10.Enabled = false;
                }

                if (charArr[8] == 'x') {
                    button11.Text = "x";
                    button11.Enabled = false;
                } else if (charArr[8] == 'o') {
                    button11.Text = "o";
                    button11.Enabled = false;
                }


            };
        }

        private void freeze() {
            button3.Enabled = false;
            button4.Enabled = false;
            button5.Enabled = false;
            button6.Enabled = false;
            button7.Enabled = false;
            button8.Enabled = false;
            button9.Enabled = false;
            button10.Enabled = false;
            button11.Enabled = false;

        }


            private void unFreeze() {
                if (button3.Text == "") {
                    button3.Enabled = true;
                }
                if (button4.Text == "") {
                    button4.Enabled = true;
                }
                if (button5.Text == "") {
                    button5.Enabled = true;
                }
                if (button6.Text == "") {
                    button6.Enabled = true;
                }
                if (button7.Text == "") {
                    button7.Enabled = true;
                }
                if (button8.Text == "") {
                    button8.Enabled = true;
                }
                if (button9.Text == "") {
                    button9.Enabled = true;
                }
                if (button10.Text == "") {
                    button10.Enabled = true;
                }
                if (button11.Text == "") {
                    button11.Enabled = true;
                }

            }
        
        private void button1_Click(object sender, EventArgs e)
        {
            


            client.Write(Encoding.UTF8.GetBytes(textBox1.Text.ToString()));
            
        }

        private void button2_Click(object sender, EventArgs e) {
            client.Connect("127.0.0.1", 50000);
            client.Write(Encoding.UTF8.GetBytes("p"));

        }
        int xCount = 0;
        int oCount = 0;

        private void okF() {
            
        }

        private void button3_Click(object sender, EventArgs e) {
            if(turn == "x") {

                button3.Text = "x";

                polje[0] = 'x';
                button3.Enabled = false;
                xCount++;
            }

            else {
                button3.Text = "o";

                polje[0] = 'o';
                button3.Enabled = false;
                oCount++;
            }
            string charsStr = new string(polje);
            client.Write(Encoding.UTF8.GetBytes(charsStr));
            freeze();

        }

        private void button4_Click(object sender, EventArgs e) {
            if (turn == "x") {

                button4.Text = "x";

                polje[1] = 'x';
                button4.Enabled = false;
                xCount++;

            } else {
                button4.Text = "o";

                polje[1] = 'o';
                button4.Enabled = false;
                oCount++;
            }
            string charsStr = new string(polje);
            client.Write(Encoding.UTF8.GetBytes(charsStr));
            freeze();
        }



        private void button5_Click(object sender, EventArgs e) {
            if (turn == "x") {

                button5.Text = "x";

                polje[2] = 'x';
                button5.Enabled = false;
                xCount++;

            } else {
                button5.Text = "o";

                polje[2] = 'o';
                button5.Enabled = false;
                oCount++;
            }
            string charsStr = new string(polje);
            client.Write(Encoding.UTF8.GetBytes(charsStr));
            freeze();
        }

        private void button6_Click(object sender, EventArgs e) {
            if (turn == "x") {

                button6.Text = "x";

                polje[3] = 'x';
                button6.Enabled = false;
                xCount++;

            } else {
                button6.Text = "o";

                polje[3] = 'o';
                button6.Enabled = false;
                oCount++;
            }
            string charsStr = new string(polje);
            client.Write(Encoding.UTF8.GetBytes(charsStr));
            freeze();
        }

        private void button7_Click(object sender, EventArgs e) {
            if (turn == "x") {

                button7.Text = "x";
 
                polje[4] = 'x';
                button7.Enabled = false;
                xCount++;

            } else {
                button7.Text = "o";

                polje[4] = 'o';
                button7.Enabled = false;
                oCount++;
            }
            string charsStr = new string(polje);
            client.Write(Encoding.UTF8.GetBytes(charsStr));
            freeze();
        }

        private void button8_Click(object sender, EventArgs e) {
            if (turn == "x") {

                button8.Text = "x";

                polje[5] = 'x';
                button8.Enabled = false;
                xCount++;

            } else {
                button8.Text = "o";

                polje[5] = 'o';
                button8.Enabled = false;
                oCount++;
            }
            string charsStr = new string(polje);
            client.Write(Encoding.UTF8.GetBytes(charsStr));
            freeze();
        }

        private void button9_Click(object sender, EventArgs e) {
            if (turn == "x") {

                button9.Text = "x";

                polje[6] = 'x';
                button9.Enabled = false;
                xCount++;

            } else {
                button9.Text = "o";

                polje[6] = 'o';
                button8.Enabled = false;
                oCount++;
            }
            string charsStr = new string(polje);
            client.Write(Encoding.UTF8.GetBytes(charsStr));
            freeze();
        }

        private void button10_Click(object sender, EventArgs e) {
            if (turn == "x") {

                button10.Text = "x";
  
                polje[7] = 'x';
                button10.Enabled = false;
                xCount++;

            } else {
                button10.Text = "o";
     
                polje[7] = 'o';
                button10.Enabled = false;
                oCount++;
            }
            string charsStr = new string(polje);
            client.Write(Encoding.UTF8.GetBytes(charsStr));
            freeze();
        }

        private void button11_Click(object sender, EventArgs e) {
            if (turn == "x") {

                button11.Text = "x";
      
                polje[8] = 'x';
                button11.Enabled = false;
                xCount++;

            } else {
                button11.Text = "o";
     
                polje[8] = 'o';
                button11.Enabled = false;
                oCount++;
            }
            string charsStr = new string(polje);
            client.Write(Encoding.UTF8.GetBytes(charsStr));
            freeze();

        }

        private void Form1_Load(object sender, EventArgs e) {

        }
    }
}
